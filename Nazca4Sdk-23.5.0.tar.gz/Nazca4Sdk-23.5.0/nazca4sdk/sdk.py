from pydantic import ValidationError
from nazca4sdk.cache import Cache
from nazca4sdk.datahandling.data_mod import Data
from nazca4sdk.businesslevel.energy_quality import EnergyQuality
from nazca4sdk.businesslevel.vibration_quality import VibrationQuality
from nazca4sdk.datahandling.variable_verificator import VariableIntervalInfo, \
    VariableIntervalSubtractionInfo
from datetime import datetime
from datetime import timedelta


class SDK:
    """SDK by Nazca4 system"""

    def __init__(self):
        """
        Initializing the system, checking connection and caching system configuration

        To get info about system:
            sdk.modules returns list of all modules
            sdk.variables returns dictionary with key:module value: available variables

        Example:
            sdk.modules -> [Module1, Module2, ... ]
            sdk.variables ->{
                                Module_Name: [Var1, Var2, ... ]
                            }
        """

        self._system_cache = Cache()
        if self._system_cache.load:
            self.modules = self._system_cache.modules
            self.variables = self._system_cache.variables
            self.types = self._system_cache.types
        else:
            print("Init SDK failed")
            self.modules = []
            self.variables = []
            self.types = []

    def variable_over_day(self, module_name, variable_names, start_date, end_date):
        """
        Gets variable in specific time range

        Args:
            module_name - name of module,
            variable_names - list of variable names,
            start_time - beginning of the time range
            stop_time - ending of the time range

        Returns:
            DataFrame: Variable values from selected time range
        """
        try:
            data = {'module_name': module_name,
                    'variable_names': variable_names,
                    'start_date': start_date,
                    'end_date': end_date}
            variable_info = VariableIntervalInfo(**data)
            result = self._system_cache.variable_over_day(variable_info.module_name,
                                                          variable_info.variable_names,
                                                          variable_info.start_date,
                                                          variable_info.end_date)
            if result is None:
                return None
            return result.to_df()
        except ValidationError as error:
            print(error.json())
            return None

    def variable_over_time(self, module_name: str,
                           variable_names: list,
                           time_amount: int,
                           time_unit: str):
        """
        Gets variable in specific time range

        Args:
            module_name - name of module,
            variable_names - list of variable names,
            time_amount - beginning of the time range
            time_unit - 'DAY','HOUR'...

        Returns:
            DataFrame: Variable values from selected time range
        """
        try:
            data = {'module_name': module_name,
                    'variable_names': variable_names,
                    'time_amount': time_amount,
                    'time_unit': time_unit}
            variable_info = VariableIntervalSubtractionInfo(**data)

            end_date = datetime.utcnow()
            start_date = end_date - self.__get_time_delta(time_unit, time_amount)

            result = self._system_cache.variable_over_day(variable_info.module_name,
                                                          variable_info.variable_names,
                                                          start_date,
                                                          end_date)
            if result is None:
                return None
            return result.to_df()
        except ValidationError as error:
            print(error.json())
            return None

    def __get_time_delta(self, time_unit, time_amount):
        if time_unit == 'SECOND':
            return timedelta(seconds=time_amount)
        elif time_unit == 'MINUTE':
            return timedelta(minutes=time_amount)
        elif time_unit == 'HOUR':
            return timedelta(hours=time_amount)
        elif time_unit == 'DAY':
            return timedelta(days=time_amount)
        elif time_unit == 'WEEK':
            return timedelta(weeks=time_amount)
        elif time_unit == 'YEAR':
            return timedelta(days=time_amount * 365)

    def get_energy_quality(self, freq1: float = 50, vol1: float = 230, cos1: float = 1, thd1: float = 0,
                           freq2: float = 50, vol2: float = 230, cos2: float = 1, thd2: float = 0,
                           freq3: float = 50, vol3: float = 230, cos3: float = 1, thd3: float = 0):

        """
        Function to determine energy quality values for determined input

        Args:
            freq1 : frequency value phase 1;
            vol1 : voltage value phase 1;
            cos1 : cosinus value phase 1;
            thd1 : thd value phase 1;
            freq2 : frequency value phase 2;
            vol2 : voltage value phase 2;
            cos2 : cosinus value phase 2;
            thd2 : thd value phase 2;
            freq3 : frequency value phase 3;
            vol3 : voltage value phase 3;
            cos3 : cosinus value phase 3;
            thd3 : thd value phase 3;
            standard : working norm type 1 - PN 50160;

        Returns:
            DataFrame: energy quality parameters

        """
        try:
            standard = 1
            energy_quality = EnergyQuality()
            data = {'freq1' : freq1,
                    'vol1': vol1,
                    'cos1': cos1,
                    'thd1': thd1,
                    'freq2': freq2,
                    'vol2': vol2,
                    'cos2': cos2,
                    'thd2': thd2,
                    'freq3': freq3,
                    'vol3': vol3,
                    'cos3': cos3,
                    'thd3': thd3,
                    'standard': standard
                    }

            result = energy_quality.calculate_energy_quality(data)
            if result is None:
                return None
            return result
        except ValidationError as error:
            print(error.json())
            return None


    def get_vibration_quality(self, group: str = 'G1r', vibration: float = 0):
        """
        Function to determine vibration quality values for determined input

        Args:
            group : Option for installation of machine according to ISO 10816
                possible: G1r, G1f,G2r, G2f,G3r, G3f,G4r, G4f ;
            vibration : Vibration value;

        Returns:
            DataFrame: vibration quality parameters

        """

        try:
            vibration_quality = VibrationQuality()
            data = {"group": group,
                    "vibration": vibration
                   }
            result = vibration_quality.calculate_vibration_quality(data)
            if result is None:
                return None
            return result
        except ValidationError as error:
            print(error.json())
            return None

    @staticmethod
    def to_list(data):
        """
        Function to modify data to list structure

        Args:
            data - input data in DataFrame format

        Returns:
            List: input data as a list
        """
        data_frame = Data(data)
        try:
            return data_frame.data_to_list()
        except RuntimeError as runtime_error:
            print(f'Problem with conversion to list - {runtime_error}')
            return None

    @staticmethod
    def to_numpy(data):
        """
        Function to modify data to numpy array structure

        Args:
            data - input data in DataFrame format

        Returns:
            np.array: input data as a numpy array
        """
        data_frame = Data(data)
        try:
            return data_frame.data_to_numpy()
        except RuntimeError as runtime_error:
            print(f'Problem with conversion to numpy array - {runtime_error}')
            return None