
class ConversionFailure(Exception):
    """
    Error handler for Conversion failure

    Returns:
        prints Error message
    """


class ArgumentMissing(Exception):
    """
    Error handler for Argument missing

    Returns:
        prints Error message
    """


class TimeConflict(Exception):
    """
    Error handler for Time conflict

    Returns:
        prints Error message
    """

