import requests
from nazca4sdk.datahandling.data_mod import Data

JSON_HEADERS = {'Content-Type': 'application/json', 'Accept': 'application/json'}


class OpenDataClient:
    """
    Get data from OpenData

    """
    def __init__(self):
        """
        Initialize OpenData url to receive system configuration

        """

        # self.base_url = 'http://10.217.1.201:10335'
        #self.base_url = 'http://10.217.10.80:61336'
        self.base_url = 'http://opendata:80'

    @staticmethod
    def parse_response(response):
        """
        Parsing method

        """
        if response.status_code == 200:
            json_response = response.json()
            if 'message' in json_response:
                print("OpenData response failure")
                return None
            return Data(json_response)

        print("OpenData response error")
        return None

    def request_params(self, module_name, grouped_variables, **time):
        """
        Creates request for OpenData

        Args:
            module_name: module_name
            grouped_variables: list of variable names
            time: **time - Time definition:
                Possible pairs: start_date end_date or time_amount time_unit
        Returns:
            request for Open Data
        """
        headers = JSON_HEADERS
        try:
            if time.get("start_date") and time.get("end_date") is not None:
                request_params = [
                    ('module', module_name),
                    ('startdate', time['start_date']),
                    ('enddate', time['end_date'])
                ]

                for t in grouped_variables:
                    for v in t[1]:
                        request_params.append((f'groupedVariables[{t[0]}]', v))

                response = requests.get(
                    f'{self.base_url}/api/HotStorage/VariableOverTime',
                    params=request_params,
                    headers=headers)

        except AttributeError:
            print('Can not mix time descriptions, use start_date end_date'
                  ' or time amount with time unit')
            return None

        return response
