import pandas as pd
from hdfs import InsecureClient
import os