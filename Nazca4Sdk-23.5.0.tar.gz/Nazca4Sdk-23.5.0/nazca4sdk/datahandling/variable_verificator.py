from datetime import datetime
from pydantic import BaseModel, validator

DATE_TIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"

class VariableIntervalInfo(BaseModel):
    """
    Class to verify the correctness of data for variable over time range
    when start and end date is set

    Args:
        dict: module parameters

    Returns:
        dict: module parameters

    """
    module_name: str
    variable_names: list
    start_date: str
    end_date: str

    @validator('start_date')
    def start_date_verify_format(cls, valid_start_date):
        """
        Validator to check if time amount is correct

        Args:
            int: valid_start_date

        Returns:
            str: valid_start_date
        """
        return VariableIntervalInfo.valid_datetime(valid_start_date)

    @validator('end_date')
    def end_date_verify_format(cls, valid_end_date, values):
        """
        Validator to check if time amount is correct

        Args:
            str: valid_end_date

        Returns:
            str: valid_end_date
        """
        VariableIntervalInfo.valid_datetime(valid_end_date)
        if 'start_date' in values:
            start_date_str = values['start_date']
            end_date = datetime.strptime(valid_end_date, DATE_TIME_FORMAT)
            start_date = datetime.strptime(start_date_str, DATE_TIME_FORMAT)
            if end_date > start_date:
                return valid_end_date
            raise ValueError(f'{valid_end_date} must be after {start_date_str}')
        else:
            raise ValueError('Cannot check if end_date is after start_date')


    @staticmethod
    def valid_datetime(valid_datetime):
        """
               Validator to check if time amount is correct

               Args:
                   int: valid_end_date

               Returns:
                   int: valid_end_date
               """
        try:
            datetime.strptime(valid_datetime, DATE_TIME_FORMAT)
            return valid_datetime
        except ValueError:
            raise ValueError('Bad datetime format. Format yyyy-mm-ddTHH:MM:SSZ')


class VariableIntervalSubtractionInfo(BaseModel):
    """
    Class to verify the correctness of data for variable over time range
     when time unit and time amount is set

    Args:
        dict: module parameters

    Returns:
        dict: module parameters

    """
    module_name: str
    variable_names: list
    time_unit: str
    time_amount: int

    @validator('time_amount')
    def time_amount_verificator(cls, valid_time_amount):
        """
        Validator to check if time amount is correct

        Args:
            int: valid_time_amount

        Returns:
            int: valid_time_amount
        """
        if valid_time_amount <= 0:
            raise ValueError('time_amount has to be greater than 0')
        return valid_time_amount

    @validator('time_unit')
    def time_unit_validator(cls, valid_time_unit):
        """
        Validator to check if time unit is correct

        Args:
            str: valid_time_unit

        Returns:
            str: valid_time_unit
        """
        possibilities = ['SECOND', 'MINUTE', 'HOUR', 'DAY', 'WEEK', 'YEAR']
        if valid_time_unit not in possibilities:
            raise ValueError('Wrong time aggregator, try: SECOND, MINUTE, HOUR, DAY, WEEK, YEAR')
        return valid_time_unit

class EnergyInput(BaseModel):
    """
    Class to verify the correctness of data for Energy Quality function to
    energy input parameters to determine energy quality assessment according to norm: PN 50160


    Args:
    freq1 : frequency value phase 1;
    vol1 : voltage value phase 1;
    cos1 : cosinus value phase 1;
    thd1 : thd value phase 1;
    freq2 : frequency value phase 2;
    vol2 : voltage value phase 2;
    cos2 : cosinus value phase 2;
    thd2 : thd value phase 2;
    freq3 : frequency value phase 3;
    vol3 : voltage value phase 3;
    cos3 : cosinus value phase 3;
    thd3 : thd value phase 3;
    standard : working norm type 1 - PN 50160;

    Returns:
        dict: energy quality parameters

    """

    freq1: float
    vol1: float
    cos1: float
    thd1: float
    freq2: float
    vol2: float
    cos2: float
    thd2: float
    freq3: float
    vol3: float
    cos3: float
    thd3: float
    standard: int

    @validator('freq1')
    def freq1_verificator(cls, valid_freq1):
        """
        Validator to check if time amount is correct

        Args:
            float: valid_frequency for phase 1

        Returns:
            float: valid_frequency for phase 1
        """
        if valid_freq1 <= 0:
            raise ValueError('Frequency of phase 1 has to be greater than 0')
        return valid_freq1

    @validator('freq2')
    def freq2_verificator(cls, valid_freq2):
        """
        Validator to check if time amount is correct

        Args:
            float: valid_frequency for phase 1

        Returns:
            float: valid_frequency for phase 1
        """
        if valid_freq2 <= 0:
            raise ValueError('Frequency of phase 2 has to be greater than 0')
        return valid_freq2

    @validator('freq3')
    def freq3_verificator(cls, valid_freq3):
        """
        Validator to check if time amount is correct

        Args:
            float: valid_frequency for phase 1

        Returns:
            float: valid_frequency for phase 1
        """
        if valid_freq3 <= 0:
            raise ValueError('Frequency of phase 3 has to be greater than 0')
        return valid_freq3

    @validator('vol1')
    def vol1_verificator(cls, valid_vol1):
        """
        Validator to check if time amount is correct

        Args:
            float: valid_voltage for phase 1

        Returns:
            float: valid_voltage for phase 1
        """
        if valid_vol1 <= 0:
            raise ValueError('Voltage V1 has to be greater than 0')
        return valid_vol1

    @validator('vol2')
    def vol2_verificator(cls, valid_vol2):
        """
        Validator to check if time amount is correct

        Args:
            float: valid_voltage for phase 2

        Returns:
            float: valid_voltage for phase 2
        """
        if valid_vol2 <= 0:
            raise ValueError('Voltage V2 has to be greater than 0')
        return valid_vol2

    @validator('vol3')
    def vol3_verificator(cls, valid_vol3):
        """
        Validator to check if time amount is correct

        Args:
            float: valid_voltage for phase 3

        Returns:
            float: valid_voltage for phase 3
        """
        if valid_vol3 <= 0:
            raise ValueError('Voltage V3 has to be greater than 0')
        return valid_vol3


class VibrationInput(BaseModel):
    """
    Class to verify the correctness of data for Energy Quality function to
    energy input parameters to determine energy quality assessment according to norm: PN 50160


    Args:
    group : (str)  Option for installation of machine according to ISO 10816
        possible: G1r, G1f,G2r, G2f,G3r, G3f,G4r, G4f ;
    vibration : (float) Vibration value;

    """
    group: str
    vibration: float

    @validator('group')
    def group_validate(cls, group):
        """
        Validator to verify group input parameter
        """

        option = ["G1r", "G1f", "G2r", "G2f", "G3r", "G3f", "G4r", "G4f"]
        if group not in option:
            raise ValueError(f'group name is specified in documentation, should be: G1r, G1f,G2r, G2f,G3r, G3f,G4r, G4f')
        return group

    @validator('vibration')
    def vibro_validate(cls, vibration):
        """
        Validator to verify vibration input parameter
        """

        vmax = 11  # Maximum vrms value according to ISO 10816
        vmin = 0   # Minimum vrms value according to ISO 10816
        if (vibration < vmin) or (vibration > vmax):
            raise ValueError('Vibration has to be in range 0 - 11')
        return float(vibration)
