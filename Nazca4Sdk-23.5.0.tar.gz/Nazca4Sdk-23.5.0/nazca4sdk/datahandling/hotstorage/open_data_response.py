from nazca4sdk.datahandling.data_mod import Data

class OpenDataResponse(Exception):

    def __init__(self, is_success: bool, message: str, data: Data):
        self.is_success = is_success
        self.message = message
        self.data = data