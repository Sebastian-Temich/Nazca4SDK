from clickhouse_driver import Client
from datetime import datetime, date


class Save:

    def __init__(self):

        self.host = '10.217.1.201'
        # Dev
        # self.host = '10.217.10.80'
        # self.port = 10990
        # Demo
        self.port = 9990
        self.user = 'click'
        self.password =  'VfA2byM0VXnpUBU9'
        self.database =  'nazca'
        self.measure_date = str(date.today())
        self.measure_time = str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        self.date = datetime.now()


        self.client = Client(host=self.host,
                             port=self.port,
                             user=self.user,
                             password=self.password,
                             database=self.database)



    def __execute(self, query):
        return self.client.execute(query)

    def __insert_data(self, module, MeasureTime, MeasureDate, Variable, Value):
        return f''' INSERT INTO nazca.devices_data_float (Module, MeasureTime, MeasureDate, Variable, Value)
        VALUES ('{module}', '{MeasureTime}', '{MeasureDate}', '{Variable}', '{Value}') '''


    def save_to_hs(self,module: str, variable: str, value: float):

        return self.__execute(self.__insert_data(module, self.measure_time,  self.measure_date, variable, value))


