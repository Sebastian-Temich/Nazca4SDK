from nazca4sdk.sdk import SDK

sdk = SDK()

print(sdk.modules)

# Examples

# Get variables from hotstorage
variablesA = sdk.variable_over_day('symulator', ["V1","V2","I1","I2"], "2022-05-09T13:11:11Z", "2022-05-09T13:11:15Z")
variablesB = sdk.variable_over_time('symulator', ["V1"], 10, "MINUTE")
print(sdk.get_energy_quality(freq1 = 50, vol1 = 230, cos1 = 1, thd1 = 0, freq2 = 50, vol2 = 230, cos2 = 1, thd2 = 0, freq3 = 50, vol3 = 230, cos3 = 1, thd3 = 0))

print(sdk.get_vibration_quality(group='G1r', vibration= 0))
