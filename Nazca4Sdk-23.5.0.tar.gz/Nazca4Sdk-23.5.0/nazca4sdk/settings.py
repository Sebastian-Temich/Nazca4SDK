import os

CONFIG_FILE_LOCATION_KEY = "CONFIG_FILE_LOCATION"
os.environ[CONFIG_FILE_LOCATION_KEY] = "Configure.yaml"
# os.environ[CONFIG_FILE_LOCATION_KEY] = "config.cfg"


def set_config_file(file):
    os.environ[CONFIG_FILE_LOCATION_KEY] = file



