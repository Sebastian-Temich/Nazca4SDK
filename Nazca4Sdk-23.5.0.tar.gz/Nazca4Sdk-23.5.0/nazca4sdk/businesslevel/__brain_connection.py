import requests
from nazca4sdk.datahandling.data_mod import Data


class BrainClient:
    """
    Get data from Nazca4 Brain
    """
    def __init__(self):
        """
        Initialize Brain connection infos

        """
        self.__brain_url = 'http://10.217.1.201:9334'

    def get_energy_quality(self, input):
        """
        Posting data to receive energy quality calculations from Brain

        """
        return requests.post(f'{self.__brain_url}/energy/', json = input)

    def get_vibration_quality(self, input):
        """
        Posting data to receive vibration quality calculations from Brain

        """
        return requests.post(f'{self.__brain_url}/vibration/', json=input)

    @staticmethod
    def parse_response(response):
        """
        Parsing method

        """
        if response.status_code == 200:
            json_response = response.json()
            if 'message' in json_response:
                print("Brain response failure")
                return None
            return Data(json_response)

        print("Brain response error")
        return None
