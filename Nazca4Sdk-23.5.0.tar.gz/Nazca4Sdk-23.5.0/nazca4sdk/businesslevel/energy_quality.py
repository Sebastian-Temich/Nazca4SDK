from nazca4sdk.businesslevel.__brain_connection import BrainClient
from nazca4sdk.datahandling.variable_verificator import  EnergyInput
from pydantic import ValidationError



class EnergyQuality:

    def __init__(self):
        self.energy_brain = BrainClient()

    def calculate_energy_quality(self, input: dict):
        """
        Function to determine energy quality values for determined input

        Args:
            ::input -> dictionary with energy parameters::
            freq1 : frequency value phase 1;
            vol1 : voltage value phase 1;
            cos1 : cosinus value phase 1;
            thd1 : thd value phase 1;
            freq2 : frequency value phase 2;
            vol2 : voltage value phase 2;
            cos2 : cosinus value phase 2;
            thd2 : thd value phase 2;
            freq3 : frequency value phase 3;
            vol3 : voltage value phase 3;
            cos3 : cosinus value phase 3;
            thd3 : thd value phase 3;
            standard : working norm type 1 - PN 50160;

        Returns:
            dict: energy quality parameters

        """

        try:
            data = dict(EnergyInput(**input))
            response = self.energy_brain.get_energy_quality(data)
            result = self.energy_brain.parse_response(response)
            if result is None:
                return None
            return result.to_df()
        except ValidationError as error:
            print(error.json())
            return None


