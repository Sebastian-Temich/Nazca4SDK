import pathlib
import sys
from setuptools import setup, find_packages

# Quick 'n dirty workaround for being able to provide "--version=1" on the command line when building the app
number_of_arguments = len(sys.argv)
version_parameter = sys.argv[-1]
version = version_parameter.split("=")[1]
sys.argv = sys.argv[0:number_of_arguments-1]

HERE = pathlib.Path(__file__).parent

with open('requirements.txt') as f:
    requirements = f.read().splitlines()

PACKAGE_NAME = 'Nazca4Sdk'
AUTHOR = 'Nazca4.0'
AUTHOR_EMAIL = ''
URL = 'https://www.apagroup.pl'

LICENSE = 'Apache License 2.0'
DESCRIPTION = 'Nazca4 SDK'
LONG_DESCRIPTION = (HERE / "README.md").read_text()
LONG_DESC_TYPE = "text/markdown"


setup(name=PACKAGE_NAME,
      version=version,
      description=DESCRIPTION,
      long_description=LONG_DESCRIPTION,
      long_description_content_type=LONG_DESC_TYPE,
      author=AUTHOR,
      license=LICENSE,
      author_email=AUTHOR_EMAIL,
      url=URL,
      include_package_data=True,
      package_data={"Nazca4Sdk": ["data/Configure.yaml"]},
      install_requires=requirements,
      packages=find_packages()
      )
